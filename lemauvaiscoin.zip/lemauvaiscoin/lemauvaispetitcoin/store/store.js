import { defineStore } from 'pinia';

export const useMainStore = defineStore('main', {
  state: () => ({
    // Ajoutez ici vos valeurs à stocker
  }),
  actions: {
    // Ajoutez ici vos méthodes pour manipuler le state
  },
});